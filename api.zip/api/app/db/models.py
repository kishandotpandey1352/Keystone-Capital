from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from .base import Base

class Watchlist(Base):
    __tablename__ = "watchlists"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    signals = relationship(
        "Signal",
        back_populates="watchlist",
        cascade="all, delete-orphan"
    )


class Signal(Base):
    __tablename__ = "signals"

    id = Column(Integer, primary_key=True, index=True)
    watchlist_id = Column(Integer, ForeignKey("watchlists.id"), nullable=False)
    value = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    watchlist = relationship(
        "Watchlist",
        back_populates="signals"
    )
