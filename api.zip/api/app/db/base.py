from sqlalchemy.orm import declarative_base
from app.db.models import Watchlist, Signal

Base = declarative_base()
